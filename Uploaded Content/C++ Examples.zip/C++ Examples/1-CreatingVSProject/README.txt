###   Instructions   ###

To run a specific example, open the Visual Studio Solution and right click the example you want to run. There should be an option called 'Set as Startup Project'. Select this and compile the program.