// Include iostream library. This allows us use of cout and cin.
#include <iostream>	

// Use std namespace
using namespace std;

int main()
{
	// Create the input variable
	int userInput = 0;

	// Get the input and save it
	cin >> userInput;

	// Output result
	cout << "The input we have given is " << userInput;

	// End main
	return 1;
}