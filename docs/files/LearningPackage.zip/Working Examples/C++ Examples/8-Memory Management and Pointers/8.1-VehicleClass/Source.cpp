// Include so we can access the Vehicle class
#include "Vehicle.h"

int main()
{
	// Nothing to do yet;
	return 0;
}