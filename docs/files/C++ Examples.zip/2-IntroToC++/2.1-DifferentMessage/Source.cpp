// Include iostream library. This allows us use of cout and cin.
#include <iostream>	

int main()
{
	// Print 'Hello World!'
	std::cout << "A totally different message!";

	// Wait for user to press a key
	std::cin.get();	

	// End of main
	return 0;						
}